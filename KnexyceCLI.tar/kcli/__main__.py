import os
os.system("clear")
print("Designed for the Linux Debian/Ubuntu Bash Terminal.")
os.system("cd kcli && chmod +x cli.sh && ./cli.sh && cd ..")
os._exit(0)