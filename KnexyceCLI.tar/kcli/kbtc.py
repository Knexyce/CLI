# KnexyceBTC

def install_pip():
    import subprocess
    import sys
    import os
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', '--version'])
        print("PIP is already installed.")
    except subprocess.CalledProcessError:
        print("PIP is not installed. Installing...")
        try:
            subprocess.check_call([sys.executable, '-m', 'ensurepip'])
            print("PIP has been installed successfully using ensurepip.")
        except subprocess.CalledProcessError:
            print("'ensurepip' failed. Attempting to install 'pip' via get-pip.py...")
            try:
                import urllib.request
                url = "https://bootstrap.pypa.io/get-pip.py"
                get_pip_script = "get-pip.py"
                urllib.request.urlretrieve(url, get_pip_script)
                print("Downloaded get-pip.py.")
                subprocess.check_call([sys.executable, get_pip_script])
                print("PIP has been installed successfully by using get-pip.py.")
                os.remove(get_pip_script)
                print("Cleaned up get-pip.py.")
            except Exception as e:
                print(f"Failed to install pip: {e}")
                sys.exit(1)

def pip_install(package_name, upgrade=False, user=False):
    import subprocess
    import sys
    import re
    def is_valid_package_name(package_name):
        return bool(re.match(r'^[a-zA-Z0-9_\-]+$', package_name))
    def install_package(package_name):
        if not is_valid_package_name(package_name):
            print(f"Invalid package name: {package_name}")
            return
        try:
            command = [sys.executable, '-m', 'pip', 'install', package_name]
            if upgrade:
                command.append('--upgrade')
            if user:
                command.append('--user')
            subprocess.run(command, check=True)
            print(f"{package_name} has been installed successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Failed to install {package_name}: {e}")
    install_package(package_name)

def upgrade_pip():
    import subprocess
    import sys
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '--upgrade', 'pip'])
        print("PIP has been upgraded successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to upgrade PIP: {e}")

def upgrade_system():
    install_pip()
    upgrade_pip()
    pip_install("secp256k1")
    pip_install("base58")
    pip_install("bit")

def create_btc_wallet():
    def generate_valid_private_key():
        while True:
            private_key_bytes = os.urandom(32)
            private_key_int = int.from_bytes(private_key_bytes, byteorder='big')
            if 1 <= private_key_int < 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141:
                return private_key_bytes
            else:
                continue
    
    def public_key_to_address(public_key):
        sha256_hash = hashlib.sha256(public_key).digest()
        ripemd160_hash = hashlib.new('ripemd160', sha256_hash).digest()
        network_prefix = b'\x00'
        prefixed_hash = network_prefix + ripemd160_hash
        checksum = hashlib.sha256(hashlib.sha256(prefixed_hash).digest()).digest()[:4]
        address_bytes = prefixed_hash + checksum
        address = base58.b58encode(address_bytes)
        return address.decode('utf-8')
    
    storage_valid_private_key = generate_valid_private_key()
    storage_private_key = PrivateKey(storage_valid_private_key)
    storage_public_key = storage_private_key.pubkey
    
    transaction_valid_private_key = generate_valid_private_key()
    transaction_private_key = PrivateKey(transaction_valid_private_key)
    transaction_public_key = transaction_private_key.pubkey
    
    storage_address = public_key_to_address(storage_public_key.serialize(compressed=True))
    transaction_address = public_key_to_address(transaction_public_key.serialize(compressed=True))
    
    print("")
    print("Bitcoin Wallet Instructions: ")
    print("Two Bitcoin wallets in total were created. One wallet is for transactions, another is to store bitcoin.")
    print("Before making a bitcoin transaction, deposit the exact transaction money into the transaction wallet along with transaction fee.")
    print("Only use your transaction wallet's private key to make a bitcoin transaction.")
    print("Only use the bitcoin storage wallet's public key to receive bitcoin.")
    print("")    
    print("Bitcoin Wallet Info: ")
    print("")
    print("Bitcoin Storage Wallet")
    print(f"Private Key: {storage_private_key.private_key.hex()}")
    print(f"Public Key: {storage_public_key.serialize().hex()}")
    print(f"Bitcoin Address: {storage_address}")
    print("")
    print("Bitcoin Transaction Wallet")
    print(f"Private Key: {transaction_private_key.private_key.hex()}")
    print(f"Public Key: {transaction_public_key.serialize().hex()}")
    print(f"Bitcoin Address: {transaction_address}")
    print("")

def try_create_wallet():
    try:
        create_btc_wallet()
    except Exception as e:
        print("Error: Unable to create a Bitcoin wallet.")

def hex_to_wif(private_key_hex, compressed=True):
    private_key_bytes = bytes.fromhex(private_key_hex)
    private_key_with_version = b'\x80' + private_key_bytes
    if compressed:
        private_key_with_version += b'\x01'
    checksum = hashlib.sha256(hashlib.sha256(private_key_with_version).digest()).digest()[:4]
    wif = base58.b58encode(private_key_with_version + checksum)
    return wif.decode('utf-8')

def wif_to_hex(wif_private_key):
    decoded = base58.b58decode(wif_private_key)
    if decoded[0] != 0x80:
        raise ValueError("Invalid WIF key: Incorrect version byte")
    private_key_bytes = decoded[1:-4]
    is_compressed = False
    if len(private_key_bytes) == 33 and private_key_bytes[-1] == 0x01:
        is_compressed = True
        private_key_bytes = private_key_bytes[:-1]
    return private_key_bytes.hex(), is_compressed

def get_transaction_fee_percentage(transaction_amount, fee_percentage):
    return transaction_amount * (fee_percentage / 100)

def create_transaction():
    private_key = input("Enter your private key. ")
    if private_key.startswith(("5", "K", "L")):
        wif_private_key = private_key
    else:
        wif_private_key = hex_to_wif(private_key)
    key = Key(wif_private_key)
    to_address = input("Enter the target Bitcoin address. ")
    amount = Decimal(input("Enter the amount of Bitcoin to send (In BTC). "))
    fee_percentage = Decimal(input("Enter the percentage of transaction fee. "))
    fee = get_transaction_fee_percentage(amount, fee_percentage)
    amount_satoshis = int(amount * 100000000)
    fee_satoshis = int(fee * 100000000)
    total_amount_satoshis = amount_satoshis + fee_satoshis
    balance = Decimal(key.get_balance('btc'))
    if balance < total_amount_satoshis:
        print("Error: Insufficient funds.")
        return
    if amount <= 0:
        print("Error: You must send a positive amount of Bitcoin.")
        return
    print(f"Creating a transaction for {amount} BTC with {fee} BTC as a fee.")
    tx = key.send([(to_address, amount_satoshis, 'btc')], fee=fee_satoshis)
    print(f"Transaction ID: {tx.txid}")
    print(f"Transaction successfully sent.")

def try_transaction():
    try:
        create_transaction()
    except Exception as e:
        print("Error: Unable to make the transaction.")

def check_balance(wif_private_key):
    key = Key(wif_private_key)
    balance = key.get_balance('btc')
    print(f"Your balance is: {balance} BTC")

def try_check():
    try:
        private_key = input("Enter your private key to check balance. ")
        wif_private_key = hex_to_wif(private_key)
        check_balance(wif_private_key)
    except Exception as e:
        print("Error: Unable to check balance.")

active = True

def clear_screen():
    import os
    import platform
    methods = [
        'cls' if platform.system() == 'Windows' else 'clear',
        'tput clear',
        'reset'
    ]
    for method in methods:
        try:
            os.system(method)
            break
        except Exception as e:
            continue
    else:
        print("Error: Unable to clear screen.")

def knexyce_command_line_help():
    print("Note: Do not include ' or ' in the command when typing.")
    print("Commands: ")
    print("'help': Provides a list of commands.")
    print("'create': Creates a Knexyce Bitcoin Wallet.")
    print("'check': Checks how much Bitcoin you have.")
    print("'send': Makes a Bitcoin transaction.")
    print("'clear': Clears the screen.")
    print("'exit': Exits the command line.")

def clean_files():
    file_path = input("Enter the name of a file containing null bytes. ") 
    try:
        with open(file_path, "rb") as f:
            content = f.read()
        clean_content = content.replace(b'\x00', b'')
        with open(file_path, "wb") as f:
            f.write(clean_content)    
        print(f"Null bytes removed successfully from '{file_path}'.")
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found. Please check the path and try again.")
    except PermissionError:
        print(f"Error: Insufficient permissions to read or write to '{file_path}'.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

def ask_clear():
    clear_ask = input("Clear screen? [y/n] ")
    if clear_ask == "y":
        clear_screen()
    else:
        pass

upgrade_ask = input("Upgrade system? [y/n] ")
if upgrade_ask == "y":
    upgrade_system()
    ask_clear()
else:
    pass

try:
    import hashlib
    import base58
    from bit import Key
    from decimal import Decimal
    import secp256k1
    import os
    from secp256k1 import PrivateKey
except Exception as e:
    print("Error: Missing dependencies.")

print("")
print("KnexyceBTC")
print("")
print("Software Info:")
print("Name: Knexyce Bitcoin (KnexyceBTC/KBTC) Command Line Interface")
print("This is a shell-agnostic script. The main requirement is internet access.")
print("This script is a Bitcoin wallet designed for a command line interface. The script is also coded in Python.")
print("This software was designed by a entity/group known as Knexyce and all rights to it are reserved by Knexyce.")
print("")
print("Advice: ")
print("It is generally good practice to use KBTC with a VPN, firewall, and antivirus for extra security along with full encryption for all internet actions/data. Save as little data as possible.")
print("It's generally recommended to research what Bitcoin is, how it works, and as much information about it as possible before using this software.")
print("Along with that, some research on how coding, software, and scripts work is generally needed to understand how this software works.")
print("")
print("To Begin:")
print("Enter 'help' without any quotations for a list of KBTC commands.")
print("")

while active:
    knexyce_input = input("<Knexyce> ")
    if knexyce_input == "help":
        knexyce_command_line_help()
    elif knexyce_input == "create":
        try_create_wallet()
    elif knexyce_input == "check":
        try_check()
    elif knexyce_input == "send":
        try_transaction()
    elif knexyce_input == "clear":
        clear_screen()
    elif knexyce_input == "exit":
        active = False
        exit()
    elif knexyce_input == "clean-null":
        clean_files()
    else:
        print("Error: Command not found.")

# This software was created by the Administrator of Knexyce.
# All rights to this software are reserved by Knexyce.