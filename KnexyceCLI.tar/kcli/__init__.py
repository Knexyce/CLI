import os
os.system("clear")
print("Designed for the Linux Debian/Ubuntu Bash Terminal.")
os.system("python3 kcli/__main__.py")
os._exit(0)