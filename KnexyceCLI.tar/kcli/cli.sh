#!/bin/bash
# Knexyce Command Line.

RED='\033[1;38;5;196m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[38;5;33m'
MAGENTA='\033[1;35m'
CYAN='\033[1;36m'
WHITE='\033[1;37m'
RESET='\033[0m'

kcli-help() {
    echo " "
    echo "Note: Do not include <, >, ', ', :, or anything beyond : when typing the command. Replace text inside of and including <> with the specified information needed for the command."
    echo " "
    echo "KNEXYCE COMMANDS: "
    echo "'browser': Starts TOR Browser (VPNs and antiviruses are recommended.)"
    echo "'btc': Starts the KnexyceBTC Wallet. (VPNs and antiviruses are recommended.)"
    echo "'system-info': Shows info on the system."
    echo "'capture': Clones a github repository."
    echo "'connect-site' <Site URL> <Amount of Requests> <Amount of Seconds Running>: Connects to a website for a certain time."
    echo "'virus-copy': Prints the code for a Linux virus into the terminal. (Three hashtags mark the beginning and end of the code.)"
    echo "'scrape': Anonymously scrapes data off of TOR's websites."
    echo "'encrypt-message': Encrypts a message that can only be decrypted by this specific software or a specific command."
    echo "'decrypt-message': Decrypts a message that was encrypted using this software."
    echo "'clear': Clears the screen."
    echo "'exit': Returns to the normal Linux terminal."
    echo " "
}

system-info() {
    echo "### System Information ###"
    uname -a
    echo -e "\n### CPU Information ###"
    lscpu
    echo -e "\n### Memory Information ###"
    free -h
    echo -e "\n### Disk Information ###"
    df -h
    echo -e "\n### Disk Partitions ###"
    sudo fdisk -l
    echo -e "\n### Hardware Information ###"
    sudo lshw -short
    echo -e "\n### Network Information ###"
    ip addr
    echo -e "\n### Network Connections ###"
    netstat -tulnp
    echo -e "\n### System Performance (top) ###"
    top -n 1 -b
    echo -e "\n### Temperature and Health ###"
    sensors
    echo -e "\n### CPU Load ###"
    uptime
    echo -e "\n### All System Summary ###"
    inxi -Fxz
}

capture() {
    echo "Enter the GitHub username. "
    read username
    echo "Enter the GitHub repository name. "
    read repo_name
    repo_url="https://github.com/$username/$repo_name.git"
    git clone "$repo_url"
    echo "Repository $repo_name by $username has been cloned. If this repository has not been cloned: One or both provided inputs may be invalid."
    echo "Check your file-system to find the repository contents that were downloaded."
    echo ""
}

connect-site() {
    pids=()
    local url=$1
    local connections=$2
    local duration=$3
    if ! [[ "$connections" =~ ^[0-9]+$ ]] || ! [[ "$duration" =~ ^[0-9]+$ ]]; then
        echo "Error: Invalid numbers for connections and duration."
        return 1
    fi
    echo "Sending requests to $url with $connections connections for $duration seconds..."
    send_requests() {
        end_time=$((SECONDS + duration))
        while (( SECONDS < end_time )); do
            curl -s -o /dev/null "$url" &
            pids+=($!)
        done
    }
    for ((i = 0; i < connections; i++)); do
        send_requests &
        pids+=($!)
    done
    sleep "$duration"
    pkill -f "curl -s -o /dev/null $url"
    for pid in "${pids[@]}"; do
        if ps -p "$pid" > /dev/null; then
            sudo kill "$pid" 2>/dev/null && echo "Killed PID: $pid" || echo "Failed to kill PID: $pid"
        else
            echo "PID $pid no longer exists."
        fi
    done
    echo "Connections have been made."
}

browser() {
    chmod +x install_tor.sh
    ./install_tor.sh
}

virus-copy() {
    echo "###"
    echo ""
    cat kfv.py
    echo ""
    echo "###"
}

btc() {
    python3 kbtc.py
}

encrypt-message() {
    read -p "Message to Encrypt: " message
    read -p "Decryption Key: " knexyce_key
    knexyce_message=$(echo -n "$message" | openssl enc -aes-256-cbc -salt -pass pass:"$knexyce_key" -pbkdf2 | base64)
    echo "Knexyce Encrypted Message:"
    echo "$knexyce_message"
    echo "Key for message decryption: $knexyce_key"
}

decrypt-message() {
    read -p "Encrypted Message: " knexyce_message
    read -p "Decryption Key: " knexyce_key
    decoded_message=$(echo "$knexyce_message" | base64 -d)    
    decrypted_message=$(echo -n "$decoded_message" | openssl enc -aes-256-cbc -d -salt -pass pass:"$knexyce_key" -pbkdf2)
    if [ $? -eq 0 ]; then
        echo "Decrypted Message: $decrypted_message"
    else
        echo "Decryption failed. Please check your key or message."
    fi
}

anonymous-scrape() {
    echo "Enter the website URL to scrape: "
    read url
    torsocks curl -s "$url" > scraped_data.html
    echo "Scraped content saved as 'scraped_data.html'."
    echo "Check your file-system to find the HTML contents that were downloaded."
}

kcli-input() {
    while true; do
        echo -en "$GREEN$username$BLUE@Knexyce: $YELLOW$(pwd)$CYAN "
        read -r input
        case "$input" in
            "system-info")
                system-info
                ;;
            "browser")
                browser
                ;;
            "capture")
                capture
                ;;
            "connect-site")
                connect-site
                ;;
            "kcli-help")
                kcli-help
                ;;
            "btc")
                btc
                ;;
            "virus-copy")
                virus-copy
                ;;
            "scrape")
                anonymous-scrape
                ;;
            "encrypt-message")
                encrypt-message
                ;;
            "decrypt-message")
                decrypt-message
                ;;
            "exit")
                echo "Exiting."
                break
                ;;
            *)
                $input
                ;;
        esac
    done
}

loading-bar() {
    clear
    echo "[=_________]"
    echo " "
    sudo apt-get install -y -qq bash
    sudo apt-get install -y -qq git
    sleep 1
    clear
    echo "[==________]"
    echo " "
    sudo apt-get install -y -qq sudo
    sudo apt-get install -y -qq tar
    sudo apt-get install -y -qq xz-utils
    sudo apt-get install -y -qq xdg-utils
    sleep 1
    clear
    echo "[===_______]"
    echo " "
    sudo apt-get install -y -qq tor
    sudo apt-get install -y -qq dpkg
    clear
    echo "[====______]"
    echo " "
    sudo apt-get install -y -qq curl
    sudo apt-get install -y -qq grep
    sudo apt-get install -y -qq wget
    sudo apt-get install -y -qq torsocks
    sleep 1
    clear
    echo "[=====_____]"
    echo " "
    sudo apt-get install -y -qq python3
    sudo apt-get install -y -qq lshw
    sudo apt-get install -y -qq net-tools
    sudo apt-get install -y -qq inxi
    sleep 1
    clear
    echo "[======____]"
    echo " "
    sudo apt-get install -y -qq lm-sensors
    sudo apt-get install -y -qq cpu-checker
    sudo apt-get install -y -qq sysstat
    sudo apt-get install -y -qq util-linux
    sleep 1
    clear
    echo "[=======___]"
    echo " "
    sudo apt-get install -y -qq fdisk
    sudo apt-get install -y -qq iproute2
    sudo apt-get install -y -qq procps
    sudo apt-get install -y -qq openssl
    sleep 1
    clear
    echo "[========__]"
    echo " "
    sudo apt-get install -y -qq coreutils
    sudo apt-get -y -qq update
    sudo apt-get -y -qq dist-upgrade
    sudo apt-get -y -qq full-upgrade
    sleep 1
    clear
    echo "[=========_]"
    sleep 0.5
    clear
    echo "[==========]: Upgraded and updated systems."
    sleep 0.5
}

echo -e "${CYAN}"
clear
echo "Upgrade system and install needed system resources?"
echo -n "y/n "
read upgrade_ask
if [[ "$upgrade_ask" == "y" ]]; then
    loading-bar
fi

echo " "
echo "Knexyce Command Line Interface"
echo " "
echo "KnexyceCLI, KCLI, or Knexyce Command Line Interface is built by a group known as Knexyce. The purpose of this software is to be a toolkit for TOR Browser."
echo " "
echo "Some features may include accessing TOR Browser, cloning github repositories, and sending connections/requests to websites."
echo " "
echo "All rights reserved by Knexyce"
echo " "
echo "Enter the command 'kcli-help' into KCLI for a list of Knexyce commands."
echo " "

echo -en "${GREEN}Enter a username: ${CYAN}"
read username
kcli-input

# Script made by Ayan Alam/Knexyce-003 in 2024 AD.
# All rights reserved by Knexyce.